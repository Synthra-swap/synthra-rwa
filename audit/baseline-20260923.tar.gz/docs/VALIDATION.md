# Validation evidence — 23 September 2026

Local toolchain: Foundry 1.5.1-stable (b0a9dd9ceda36f63e2326ce530c10e6916f4b8a2),
Solidity 0.8.28 (7893614a), Slither 0.11.3, Python 3.14.6. EVM Paris, optimizer 200,
no CBOR/bytecode metadata. CI declares Foundry 1.5.1 and Python 3.11 but has not been run remotely.

`bash tools/check.sh` completed successfully for this source candidate. The reports below are
packaged and hashed with the source snapshot; the independent audit remains outstanding.

| Check | Result | Evidence |
| --- | --- | --- |
| Solidity suite | 63 passed, 0 failed, 0 skipped | `audit/unit-tests.log` |
| Audit profile | 63 passed; 4 fuzz tests × 2,048 cases | `audit/audit-tests.log` |
| Stateful conservation | 512 runs × depth 128 = 65,536 handler calls; 0 unexpected reverts | `audit/audit-tests.log` |
| Pending-message drain | afterInvariant delivers outstanding messages and checks locked = supply | `test/BridgeInvariant.t.sol` |
| Native binary signed VAAs | 8 tests against unmodified Wormhole parser/quorum/signature code, two distinct EVM domains | `test/SignedVAA.t.sol` |
| Fee behavior | 100 → 99.5 wrapped + immediate 0.5 treasury; failed fee/publication fully reverts | `test/Bridge.t.sol` |
| Deployment simulation | Both sides created paused and owned by newly created timelock; placeholders rejected | `test/DeploymentConfig.t.sol` |
| Operational-tool validation | 8 Python tests passed | `tools/test_preflight.py` |
| Slither | 0 High/Medium, 6 reviewed Low timestamp findings | `audit/slither.json`, `docs/SECURITY_ANALYSIS.md` |
| Formatting / dependencies | Passed; 65 dependency files match lock | `tools/check.sh`, `vendor/SHA256SUMS.json` |
| Demo | Successful simulation; 9.95 minted, 4 redeemed, 5.95 remaining, 0.05 immediately paid | `audit/demo.log` |

## Coverage

These are instrumented Foundry coverage numbers, not a proof of correctness or absence of vulnerabilities.
Source-only total: 247/249 lines (99.20%), 48/48 functions (100%), 39/46 branches (84.78%).

| Contract | Lines | Functions | Branches |
| --- | --- | --- | --- |
| SourceVault | 50/51 | 6/6 | 9/11 |
| DestinationBridge | 25/26 | 5/5 | 2/5 |
| WormholeEndpoint | 99/99 | 18/18 | 19/21 |
| WrappedAsset | 64/64 | 17/17 | 7/7 |
| TokenBucket | 9/9 | 2/2 | 2/2 |

Deployment script: 51/51 lines and 3/3 functions; 10/16 branches. Full file-by-file summary and
LCOV in `audit/coverage.log` and `audit/coverage.lcov`. Uncovered branches include invalid deployment/
configuration paths and redundant remote-token rejection; these remain visible for auditor review.

Production runtime sizes: SourceVault 11,596 bytes, DestinationBridge 9,787 bytes, WrappedAsset
4,455 bytes; all below EIP-170's 24,576-byte limit. Gas output is in `audit/gas-report.log` and
includes artificial mock overhead; it is not a gas-cost estimate for the live chains.

## What has not been established

- No public testnet/mainnet transaction was broadcast, no remote fork/integration test was executed.
- The signed-VAA harness initializes synthetic Guardian keys; it does not contact the actual Guardian
  network, observe real source transactions or exercise production proxy governance/upgrades.
- Actual original token contracts, escrow/treasury eligibility, Core deployments, chain finality,
  live code hashes, risk limits and operational wallet addresses are unconfigured.
- Read-only network preflight and live relay simulation require those real configs/RPCs and have
  not been run. Config validation tests are not a replacement for network testing.
- No independent security audit, issuer/legal review, hosted relayer, event-indexer reconciliation,
  frontend execution or liquidity validation was performed.

Foundry emits non-blocking debug-source-parser warnings during the demo for certain test/vendor
files. Compilation, script assertions, emitted logs and final exit code confirm successful execution.
One intentional Slither suppression ignores only the unused human-readable Core diagnostic string;
validity is checked explicitly. Disposition is documented, not represented as a detector-free audit.
