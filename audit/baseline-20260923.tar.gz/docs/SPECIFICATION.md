# Protocol specification

All transfer amounts are unsigned **raw token units** with 18 decimals. They are not share counts.
The source asset address is an immutable allowlisted asset by construction; there is no ticker lookup
or user-supplied asset registration. User addresses are unrestricted.

## Deposit and fee

For gross amount G > 0:

- F = floor(G * 50 / 10000), N = G - F.
- Debit source outbound bucket by G, check outstanding cap against N.
- Transfer G original tokens from caller to vault, checking exact received balance delta.
- Increase locked by N; transfer F immediately to immutable feeRecipient, checking both exact
  vault debit and recipient credit. For F = 0, no fee transfer/event occurs.
- Publish a DEPOSIT message for N to the chosen destination recipient.

All steps are one local transaction. A fee-transfer failure, Core publication failure or other revert
undoes the deposit, fee, accounting, allowance spending and bucket debit. A later failure or delay
on the other chain does **not** refund the fee. Fee is collected on successful source initiation.
Tiny deposits below 200 raw units pay zero after rounding; splitting can save less than one raw unit
per deposit. Native message fees and gas are separate. No commercial fee applies to redemption.

## Mint / burn / redemption

Anyone may deliver a valid deposit VAA. Validate envelope and payload, debit destination inbound
bucket by N, enforce supply cap, and mint N wrapped to the encoded recipient.

`redeem(A, sourceRecipient)` burns A from **msg.sender** only and publishes REDEEM. There is no
allowance-based burn of other holders. Debit destination outbound bucket by A. Anyone can deliver
the resulting VAA to the vault: debit source inbound bucket by A, reduce locked and transfer A
original tokens to the signed recipient, verifying exact balance deltas.

Consumed-message writes and bucket debits revert if mint or transfer fails. No timeout refunds,
manual reserve recovery or administrative message cancellation exist: unilateral refunds would
permit a later mint against released collateral. Frozen originals can make exits wait indefinitely.

## Message wire format

Wormhole Core validates the native binary VAA. Local code decodes **only its verified payload**.
Header fields, in ABI order:

| Field | Type / condition |
| --- | --- |
| domain | bytes32, keccak256("synthra.rwa.bridge.v1") |
| version | uint8, 1 |
| action | uint8: 1 deposit, 2 redeem, 3 metadata |
| sourceEvmChain | uint256, remoteEvmChain |
| destinationEvmChain | uint256, deploymentChainId |
| destinationChain | uint16, local Wormhole ID |
| destinationBridge | address, receiving endpoint |
| originToken | address, original source token |

Transfers append `address recipient, uint256 amount`: exactly 320 bytes.
Metadata appends `uint256 observedAt, uint256 current, uint256 next, uint256 effectiveAt`:
exactly 384 bytes. Extra trailing data and truncated payloads are rejected. The prototype wire
format from before this candidate is not compatible; no production deployment used it.

Envelope must have remoteWormholeChain, padded remote peer address and exact configured
inbound consistency enum. Consistency numbers are not an ordered security scale. Replay identity:
`keccak256(abi.encode(emitterChainId, emitterAddress, sequence))`. Guardian re-signing/alternative
quorums do not change this identity. No expiry is imposed on transfer payloads by the bridge;
Core guardian-set expiry can still make a stale attestation unusable.

## Accounting and temporal limits

Under honest finality and valid attestations, for a causally consistent cut of both chains:

`locked = totalSupply + pendingNetDeposits + pendingRedemptions`

`sourceToken.balanceOf(vault) >= locked` (surplus may be unsolicited donations).
FeeRecipient has received the sum of F for successful source deposits. Fees are not collateral.
At full delivery, locked = supply. Separate wall-clock snapshots must not be presented as an
atomic proof; the event indexer needs finalized events and their corresponding consumptions.

Each endpoint has independent inbound/outbound token buckets. Both start at capacity C.
After elapsed t, available = min(C, stored + floor(t * C / refillSeconds)); at t >= refillSeconds
it is C. Successful transfer debit stores remaining balance and current timestamp. Failed
transactions cannot consume capacity. Rounding is conservative; partially accrued raw fractions
may be discarded on a successful debit. There is no fixed window with a double-spend boundary.
Maximum transfer and outstanding cap are separate immutable limits. Capacity is bounded to uint128,
refill interval to (0,30 days]. No admin refill, limit increase or privileged bypass exists.

## Multiplier snapshots

A permissionless keeper calls `publishMetadata`, paying the Core message fee. The source reads
uiMultiplier/newUIMultiplier/effectiveAt directly from the original. If no future schedule exists,
it normalizes next=current and effectiveAt=0. No caller can submit arbitrary multiplier values.

Destination verifies the METADATA VAA before passing its emitter sequence to WrappedAsset.
Only later sequences replace current state. Older authenticated snapshots are consumed but ignored.
A replacement can supersede or cancel a pending schedule. Observed timestamp must not decrease,
must be no more than 5 minutes in the future and no older than configured metadataMaxAge.
Current and next must be positive; a future schedule must be after the observation time.

Raw ERC20 balances, supply, allowances and burn/redeem are independent from snapshots.
UI accessors and conversions revert before the first snapshot or when stale. `snapshot()` remains
readable for monitoring. This is an intentional fail-closed deviation from the happy-path behavior
of ERC-8056 UI consumers, which must handle reverts and check metadataFresh. ERC-8056 is a draft.
A source cancellation cannot be known before its message arrives; a schedule may temporarily be
wrong within the freshness bound. These values are **not a price oracle**. No double application
to an already multiplier-adjusted price is permitted in an integrating frontend.
