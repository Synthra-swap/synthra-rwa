# Deployment and operations runbook

No live deployment is configured or authorized by the example files. They intentionally contain
zero addresses/domains; the script and preflight reject them. Never replace unknown values with
unverified guesses. Scripts do not load or print private keys.

## 1. Before deployment

Complete one deployment JSON per chain from `config/deployment.example.json` and a pair file from
`config/pair.example.json`. Store reviewed real copies outside the audit archive. Verify against dated
primary sources and RPC reads:

- EVM and Wormhole IDs; Core proxy and current implementation code/provenance/governance.
- Accepted finality/consistency enum on each chain and actual Guardian support in both directions.
- Official original-token registry entry, bytecode/proxy, 18 decimals, raw transfer semantics,
  freeze/upgrade powers, multiplier API and permissionless wrapper compatibility.
- Governance Safe signers/thresholds and emergency guardian; distinct contract addresses. Script
  checks contract existence, not Safe authenticity or threshold correctness.
- Treasury ownership/access and ability to receive the source token. It is immutable.
- Per-transfer maximum, bucket capacity/refill, outstanding cap and metadata freshness agreed with
  risk owners. Numbers in examples are test parameters, not production recommendations.

Keep cap, rateCapacityRaw, maxTransferRaw and refillSeconds equal on both endpoints. Consistency
is reciprocal: source outbound = destination inbound, and vice versa. Match origin asset address.

```sh
python3 tools/preflight.py --pair config/pair.json --config-only
```

This checks configuration coherence only. It does not contact a network or establish legal approval.

## 2. Deploy each side paused

Simulate first against the correct RPC with a named keystore/hardware wallet (never a private key in
source/config). `Deploy` creates a TimelockController and one endpoint. Destination creates its
wrapped ERC20 internally. Source feeRecipient is fixed immediately. The script never unpauses.

```sh
DEPLOY_CONFIG=config/source.json forge script script/Deploy.s.sol:Deploy \
  --rpc-url "$SOURCE_RPC_URL" --account deployer
```

The command above is a simulation. Broadcasting is a separate operator action after checking output
and review: the same command with `--broadcast`. Do not broadcast LocalDemo. Save receipts, chain IDs,
constructor arguments, exact artifact/runtime hashes and governance addresses in the deployment record.
Verify source on the explorer using the audited compiler settings and constructor args.
A two-contract deployment is not atomic across transactions; if interrupted, reconcile receipts before
retrying to avoid confusing duplicate governors/endpoints. There is no automated resume/migration tool.

## 3. Bind the pair through governance

Schedule timelock calls (proposer Safe), wait the configured delay, then execute (executor Safe):

- Source `setPeer(destinationEndpoint, destinationWrappedToken)`.
- Destination `setPeer(sourceVault, originalSourceToken)`.

Both bindings are one-time. Verify the actual remote addresses before scheduling. No owner can change
them later. A mistake requires a new pair. Do not activate deposits before checking the reciprocal
binding and token identities.

Enter reviewed runtime hashes and deployment addresses in the pair file. Run:

```sh
python3 tools/preflight.py --pair config/pair.json --phase prepared
```

It pins independent finalized blocks, validates domains, owners, peers, remote tokens, parameters,
fees, paused state, governance roles and source backing, then rechecks block hashes. It intentionally
fails if the RPC does not support the finalized tag. It does not prove a Core proxy implementation,
issuer registry membership or all historical governance-role assignments: verify these separately.
Expected runtime hashes must come from reviewed artifacts, never blindly accept current RPC bytecode.

Schedule/execute `unpause(3)` on both endpoints via timelocks after all checks and the audit sign-off.
Initial metadata requires source outbound + destination inbound enabled. Publish and relay a snapshot,
then test one minimum-size round trip, fee payment and manual relay before widening exposure. The
limits themselves are immutable; selecting a different cap requires deploying a new reviewed pair.

## 4. Relay and retry

Retrieve a native binary signed VAA from the selected Wormhole attestation service. Keep the source
transaction, finalized emitter/sequence, raw VAA, destination transaction and status in durable storage.
A custom worker should persist before submitting, deduplicate by emitter chain/address/sequence,
use bounded retry/backoff, track receipts through finality and handle reorgs. The repository provides
manual relay preparation, not a hosted always-on worker.

```sh
python3 tools/prepare_relay.py --kind deposit --vaa deposit-vaa.hex \
  --endpoint "$DESTINATION_ENDPOINT" --sender "$RELAYER_ADDRESS" \
  --rpc-env DESTINATION_RPC_URL --chain-id "$DESTINATION_EVM_CHAIN_ID"
```

Output is an **unsigned** transaction after `eth_call` and gas estimation. Sign/send through the
operator's normal wallet tooling after re-simulation. `--kind redemption` targets the source vault;
`--kind metadata` targets DestinationBridge. The helper never signs or transmits. Any address can
relay; no Synthra key is needed to complete a user's valid message.

- Rate limit: wait for capacity and retry the same VAA; do not create a second user deposit.
- Endpoint pause: investigate and resume via governance when safe; pending VAA remains usable.
- Original issuer freeze/tax behavior: investigate with issuer. Reverts do not consume the claim.
- Already consumed: confirm finalized destination event; treat as completed only after reconciliation.
- Stale metadata: publish a new snapshot; original transfers remain denominated in raw units.
- Expired Guardian set / long outage: work with Wormhole; do not fabricate attestations, force mint,
  or refund from reserves. This implementation has no privileged emergency recovery route.

## 5. Monitoring and incidents

Monitor finalized events and checks at a cadence shorter than the selected rate-refill/freshness
windows; the operators must define actual latency and alert SLOs before launch.

| Signal | Response |
| --- | --- |
| Source balance below locked | Emergency pause affected inbound/outbound, investigate issuer/transfer behavior |
| Unexplained mint/unlock or wrong emitter evidence | Pause inbound on both endpoints immediately; preserve VAAs/logs |
| Stuck transfers / Guardian/RPC outage | Stop new admissions if appropriate, keep safe exit path available, disclose pending state |
| Nearly exhausted bucket | Queue/retry rather than mutate immutable limits |
| Missing/stale multiplier | Publish/relay fresh state; disable share-equivalent quotes/UI; raw redemption continues |
| Ownership/guardian/Timelock role or delay change | Review schedule/transactions before delayed execution |
| Core implementation or issuer proxy upgrade | Review compatibility; pause admissions if uncertain |
| Treasury fee-transfer failure | New deposits revert; investigate; principal already locked can still be redeemed |

Guardian `pause(1)` stops outbound initiation, `pause(2)` stops inbound execution, `pause(3)` stops both.
For ordinary maintenance stop only source outbound, preserving exits. Security incidents may require
stopping inbound despite delaying withdrawals. `unpause` is owner-only and timelocked by deployment
configuration. Neither incident response nor governance can seize backing or freeze wrapped transfers.

## 6. Frontend integration obligations

Show gross amount, 0.5% fee, net wrapped amount, separate gas/message fees and an asynchronous state
machine before signing. Fee is collected at source success even if remote completion is delayed.
Validate destination addresses including known endpoint/token contracts; never label a raw token as
one share. Show metadata freshness and handle UI accessor reverts. Prices are external data with
explicit units; metadata is not an oracle. Do not advertise instant cross-chain settlement or an
atomic 100% proof from unsynchronized snapshots.
