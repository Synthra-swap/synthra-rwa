import copy
import unittest
from preflight import validate_pair,word,address

def fixture():
    source={'sourceSide':True,'evmChain':111,'remoteEvmChain':222,'wormholeChain':100,'remoteWormholeChain':200,
    'core':'0x'+'1'*40,'sourceAsset':'0x'+'2'*40,'governanceSafe':'0x'+'3'*40,'guardian':'0x'+'4'*40,'treasury':'0x'+'5'*40,
    'governanceDelaySeconds':172800,'metadataMaxAgeSeconds':86400,'capRaw':'1000','rateCapacityRaw':'100','maxTransferRaw':'10',
    'refillSeconds':3600,'outboundConsistency':1,'inboundConsistency':1}
    dest=copy.deepcopy(source);dest.update(sourceSide=False,evmChain=222,remoteEvmChain=111,wormholeChain=200,remoteWormholeChain=100)
    return source,dest
class PreflightTests(unittest.TestCase):
    def test_valid_pair(self):validate_pair(*fixture())
    def test_wrong_remote_domain(self):
        s,d=fixture();d['remoteEvmChain']=999
        with self.assertRaisesRegex(ValueError,'reciprocal'):validate_pair(s,d)
    def test_zero_address_placeholder(self):
        s,d=fixture();s['treasury']='0x'+'0'*40
        with self.assertRaisesRegex(ValueError,'placeholder'):validate_pair(s,d)
    def test_limits_mismatch(self):
        s,d=fixture();d['capRaw']='1001'
        with self.assertRaisesRegex(ValueError,'limit mismatch'):validate_pair(s,d)
    def test_short_timelock(self):
        s,d=fixture();s['governanceDelaySeconds']=1
        with self.assertRaisesRegex(ValueError,'too short'):validate_pair(s,d)
    def test_finality_not_numerically_ordered(self):
        s,d=fixture();s['outboundConsistency']=200;d['inboundConsistency']=201
        with self.assertRaisesRegex(ValueError,'consistency'):validate_pair(s,d)
    def test_canonical_abi(self):
        self.assertEqual(word('0x'+'0'*63+'1'),1)
        with self.assertRaises(ValueError):word('0x1')
    def test_no_shell_address_injection(self):
        with self.assertRaises(ValueError):address('$(cat .env)')
if __name__=='__main__':unittest.main()
