#!/usr/bin/env python3
import json
from pathlib import Path
report=json.loads((Path(__file__).resolve().parents[1]/'audit/slither.json').read_text())
if not report.get('success'):
    raise SystemExit('Slither did not finish successfully')
findings=report.get('results',{}).get('detectors',[])
blocking=[f for f in findings if f['impact'] in ('High','Medium')]
# Do not silently accept new low/informational categories; review every changed finding class.
unreviewed=[f for f in findings if f['check']!='timestamp']
if blocking or unreviewed:
    raise SystemExit('Unreviewed static-analysis findings: '+', '.join(f['check'] for f in blocking+unreviewed))
print(f'Slither: no high/medium findings; {len(findings)} timestamp findings reviewed in docs/SECURITY_ANALYSIS.md')
