#!/usr/bin/env python3
"""Read-only paired-deployment validation at finalized, rechecked block snapshots. No signing."""
import argparse
import json
import os
import re
import subprocess
import sys
import urllib.request
from pathlib import Path

ZERO = '0x' + '0' * 40

def require(condition, message):
    if not condition:
        raise ValueError(message)

def address(value):
    require(isinstance(value, str) and re.fullmatch(r'0x[0-9a-fA-F]{40}', value), 'invalid address')
    require(value.lower() != ZERO, 'zero address placeholder')
    return value.lower()

def cast(*args):
    return subprocess.check_output(['cast', *args], text=True).strip()

def word(value):
    require(isinstance(value,str) and re.fullmatch(r'0x[0-9a-fA-F]{64}',value), 'noncanonical ABI word')
    return int(value,16)

def validate_pair(source, destination):
    require(source['sourceSide'] is True and destination['sourceSide'] is False, 'sourceSide mismatch')
    for c in (source,destination):
        for name in ('core','sourceAsset','governanceSafe','guardian','treasury'):
            address(c[name])
        require(c['governanceSafe'].lower()!=c['guardian'].lower(),'guardian must differ from governance')
        require(0<int(c['wormholeChain'])<=65535 and 0<int(c['remoteWormholeChain'])<=65535,'invalid Wormhole domain')
        require(0<int(c['evmChain'])!=int(c['remoteEvmChain'])>0,'invalid EVM domains')
        require(0<int(c['maxTransferRaw'])<=int(c['rateCapacityRaw'])<=int(c['capRaw']),'invalid amount limits')
        require(int(c['rateCapacityRaw'])<2**128,'capacity overflow')
        require(0<int(c['refillSeconds'])<=30*86400,'invalid refill period')
        require(int(c['governanceDelaySeconds'])>=172800,'governance delay too short')
        require(0<int(c['metadataMaxAgeSeconds'])<=7*86400,'invalid metadata age')
        for k in ('outboundConsistency','inboundConsistency'):
            require(0<=int(c[k])<=255,'invalid consistency enum')
    for a,b in ((source,destination),(destination,source)):
        require(int(a['remoteEvmChain'])==int(b['evmChain']),'EVM reciprocal mismatch')
        require(int(a['remoteWormholeChain'])==int(b['wormholeChain']),'Wormhole reciprocal mismatch')
        require(int(a['outboundConsistency'])==int(b['inboundConsistency']),'consistency mismatch')
    require(source['wormholeChain']!=destination['wormholeChain'],'same Wormhole domain')
    require(source['sourceAsset'].lower()==destination['sourceAsset'].lower(),'origin asset mismatch')
    for k in ('capRaw','rateCapacityRaw','refillSeconds','maxTransferRaw'):
        require(int(source[k])==int(destination[k]),f'paired limit mismatch: {k}')

class RPC:
    def __init__(self,url):
        require(url.startswith(('https://','http://')),'invalid RPC protocol')
        self.url=url
    def request(self,method,params):
        payload=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode()
        try:
            req=urllib.request.Request(self.url,payload,{'Content-Type':'application/json'})
            with urllib.request.urlopen(req,timeout=30) as result:
                data=json.load(result)
        except Exception as error:
            raise ValueError('RPC transport failed (URL omitted)') from error
        require('error' not in data, f'RPC {method} rejected; inspect provider separately')
        require('result' in data,'RPC missing result')
        return data['result']
    def call(self,target,signature,block,*args):
        data=cast('calldata',signature,*[str(a) for a in args])
        return word(self.request('eth_call',[{'to':target,'data':data},block]))

def inspect(c,meta,remote_meta,phase):
    rpc=RPC(os.environ[meta['rpcEnv']]);endpoint=address(meta['endpoint']);governor=address(meta['timelock'])
    require(int(rpc.request('eth_chainId',[]),16)==int(c['evmChain']),'RPC on wrong chain')
    block=rpc.request('eth_getBlockByNumber',['finalized',False]);require(block is not None,'finalized block unavailable')
    pin=block['number']
    def call(target,signature,*args): return rpc.call(target,signature,pin,*args)
    def eq(signature,expected): require(call(endpoint,signature)==int(expected),f'endpoint mismatch: {signature}')
    for target,expected_hash in ((endpoint,meta['endpointCodeHash']),(c['core'],meta['coreCodeHash'])):
        require(re.fullmatch(r'0x[0-9a-fA-F]{64}',expected_hash),'missing approved code hash')
        code=rpc.request('eth_getCode',[target,pin]);require(code!='0x','missing code')
        require(cast('keccak',code).lower()==expected_hash.lower(),'approved runtime hash mismatch')
    eq('owner()',int(governor,16));eq('peer()',int(address(remote_meta['endpoint']),16))
    eq('wormhole()',int(c['core'],16));eq('guardian()',int(c['guardian'],16))
    eq('deploymentChainId()',c['evmChain']);eq('remoteEvmChain()',c['remoteEvmChain'])
    eq('localWormholeChain()',c['wormholeChain']);eq('remoteWormholeChain()',c['remoteWormholeChain'])
    eq('outboundConsistency()',c['outboundConsistency']);eq('inboundConsistency()',c['inboundConsistency'])
    for getter,key in [('rateCapacity()','rateCapacityRaw'),('refillSeconds()','refillSeconds'),('maxTransfer()','maxTransferRaw')]: eq(getter,c[key])
    eq('pausedLanes()',3 if phase=='prepared' else 0)
    require(call(c['core'],'chainId()')==int(c['wormholeChain']),'Core Wormhole domain mismatch')
    require(call(c['core'],'evmChainId()')==int(c['evmChain']),'Core EVM domain mismatch')
    require(call(governor,'getMinDelay()')>=int(c['governanceDelaySeconds']),'timelock delay mismatch')
    for role in ('PROPOSER_ROLE','EXECUTOR_ROLE'):
        require(call(governor,'hasRole(bytes32,address)',cast('keccak',role),c['governanceSafe'])==1,'governance role missing')
    require(call(governor,'hasRole(bytes32,address)','0x'+'0'*64,c['governanceSafe'])==0,'Safe has direct admin role')
    state={'block':pin,'blockHash':block['hash'],'timestamp':int(block['timestamp'],16),'endpoint':endpoint}
    state['remoteToken']='0x'+format(call(endpoint,'remoteToken()'),'040x')
    state['inboundAvailable']=str(call(endpoint,'inboundAvailable()'));state['outboundAvailable']=str(call(endpoint,'outboundAvailable()'))
    if c['sourceSide']:
        eq('asset()',int(c['sourceAsset'],16));eq('feeRecipient()',int(c['treasury'],16));eq('FEE_BPS()',50);eq('reserveCap()',c['capRaw'])
        require(call(c['sourceAsset'],'decimals()')==18,'asset decimals mismatch')
        state['lockedRaw']=str(call(endpoint,'locked()'));state['balanceRaw']=str(call(c['sourceAsset'],'balanceOf(address)',endpoint))
        require(int(state['balanceRaw'])>=int(state['lockedRaw']),'local escrow backing deficit')
        require(call(c['sourceAsset'],'uiMultiplier()')>0,'invalid original multiplier')
        call(c['sourceAsset'],'newUIMultiplier()');call(c['sourceAsset'],'effectiveAt()')
    else:
        eq('originToken()',int(c['sourceAsset'],16));eq('supplyCap()',c['capRaw'])
        wrapped='0x'+format(call(endpoint,'wrappedAsset()'),'040x');state['wrapped']=wrapped
        eq('remoteToken()',int(c['sourceAsset'],16))
        require(call(wrapped,'bridge()')==int(endpoint,16),'wrapped bridge mismatch')
        require(call(wrapped,'metadataMaxAge()')==int(c['metadataMaxAgeSeconds']),'metadata age mismatch')
        state['supplyRaw']=str(call(wrapped,'totalSupply()'));state['metadataFresh']=bool(call(wrapped,'metadataFresh()'))
    check=rpc.request('eth_getBlockByNumber',[pin,False]);require(check is not None and check['hash']==block['hash'],'pinned block changed')
    return state

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pair',required=True);parser.add_argument('--phase',choices=['prepared','active'],default='prepared');parser.add_argument('--config-only',action='store_true');args=parser.parse_args()
    pair=json.loads(Path(args.pair).read_text());source=json.loads(Path(pair['source']['deployment']).read_text());destination=json.loads(Path(pair['destination']['deployment']).read_text())
    validate_pair(source,destination)
    if args.config_only:
        print(json.dumps({'configValid':True,'networkChecked':False}));return
    results={name:inspect(c,pair[name],pair[other],args.phase) for name,other,c in [('source','destination',source),('destination','source',destination)]}
    require(results['source']['remoteToken']==results['destination']['wrapped'],'source remote token mismatch')
    results['notice']='Separate finalized snapshots, not an atomic proof of cross-chain solvency. Core proxy implementation/governance and emitter provenance require separate review.'
    print(json.dumps(results,indent=2))
if __name__=='__main__':
    try: main()
    except (ValueError,KeyError,OSError,subprocess.CalledProcessError) as error:
        print(f'Preflight failed: {error}',file=sys.stderr);sys.exit(1)
