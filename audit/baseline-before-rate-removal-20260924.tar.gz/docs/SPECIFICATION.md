# Protocol specification

All transfer amounts are unsigned **raw token units** with 18 decimals. They are not share counts.
The source asset address is an immutable allowlisted asset by construction; there is no ticker lookup
or user-supplied asset registration. User addresses are unrestricted.

## Deposit and fee

For gross amount G > 0:

- F = floor(G * 50 / 10000), N = G - F.
- Check the per-transfer maximum and debit source outbound bucket by G.
- Transfer G original tokens from caller to vault, checking exact received balance delta.
- Increase locked by N; transfer F immediately to the current feeRecipient, checking both exact
  vault debit and recipient credit. For F = 0, no fee transfer/event occurs.
- Publish a DEPOSIT message for N to the chosen destination recipient.

All steps are one local transaction. A fee-transfer failure, Core publication failure or other revert
undoes the deposit, fee, accounting, allowance spending and bucket debit. A later failure or delay
on the other chain does **not** refund the fee. Fee is collected on successful source initiation.
Governance may call `setFeeRecipient(next)` through the endpoint owner (the deployment timelock).
Zero, the vault itself and the original token address are rejected. The change emits
`FeeRecipientChanged(previous,next)` and affects deposits initiated after execution, including when
the vault is currently paused. It does not move existing reserves or previously paid fees, change
the fee rate, or alter pending cross-chain claims. Rotation cannot occur during a guarded transfer.
Recipient ownership and issuer transfer eligibility must be checked operationally before scheduling.

Tiny deposits below 200 raw units pay zero after rounding; splitting can save less than one raw unit
per deposit. Native message fees and gas are separate. No commercial fee applies to redemption.

## Mint / burn / redemption

Anyone may deliver a valid deposit VAA. Validate envelope and payload, debit destination inbound
bucket by N, enforce the historical inbound maximum, and mint N wrapped to the encoded recipient.

`redeem(A, sourceRecipient)` burns A from **msg.sender** only and publishes REDEEM. There is no
allowance-based burn of other holders. Debit destination outbound bucket by A. Anyone can deliver
the resulting VAA to the vault: debit source inbound bucket by A, reduce locked and transfer A
original tokens to the signed recipient, verifying exact balance deltas.

Consumed-message writes and bucket debits revert if mint or transfer fails. No timeout refunds,
manual reserve recovery or administrative message cancellation exist: unilateral refunds would
permit a later mint against released collateral. Frozen originals can make exits wait indefinitely.

## Message wire format

Wormhole Core validates the native binary VAA. Local code decodes **only its verified payload**.
Header fields, in ABI order:

| Field | Type / condition |
| --- | --- |
| domain | bytes32, keccak256("synthra.rwa.bridge.v1") |
| version | uint8, 1 |
| action | uint8: 1 deposit, 2 redeem, 3 metadata |
| sourceEvmChain | uint256, remoteEvmChain |
| destinationEvmChain | uint256, deploymentChainId |
| destinationChain | uint16, local Wormhole ID |
| destinationBridge | address, receiving endpoint |
| originToken | address, original source token |

Transfers append `address recipient, uint256 amount`: exactly 320 bytes.
Metadata appends `uint256 observedAt, uint256 current, uint256 next, uint256 effectiveAt`:
exactly 384 bytes. Extra trailing data and truncated payloads are rejected. The prototype wire
format from before this candidate is not compatible; no production deployment used it.

Envelope must have remoteWormholeChain, padded remote peer address and exact configured
inbound consistency enum. Consistency numbers are not an ordered security scale. Replay identity:
`keccak256(abi.encode(emitterChainId, emitterAddress, sequence))`. Guardian re-signing/alternative
quorums do not change this identity. No expiry is imposed on transfer payloads by the bridge;
Core guardian-set expiry can still make a stale attestation unusable.

## Accounting and temporal limits

Under honest finality and valid attestations, for a causally consistent cut of both chains:

`locked = totalSupply + pendingNetDeposits + pendingRedemptions`

`sourceToken.balanceOf(vault) >= locked` (surplus may be unsolicited donations).
The sum paid to all fee recipients over time equals the sum of F for successful source deposits.
Fees are not collateral; changing the recipient does not reassign earlier payments.
At full delivery, locked = supply. Separate wall-clock snapshots must not be presented as an
atomic proof; the event indexer needs finalized events and their corresponding consumptions.

Each endpoint has independent inbound/outbound token buckets. Both start at capacity C.
After elapsed t, available = min(C, stored + floor(t * C / refillSeconds)); at t >= refillSeconds
it is C. Successful transfer debit stores remaining balance and current timestamp. Failed
transactions cannot consume capacity. Rounding is conservative; partially accrued raw fractions
may be discarded on a successful debit. There is no fixed window with a double-spend boundary.
There is no configured total cap on locked reserves or wrapped supply. Their cumulative amounts may
exceed bucket capacity across refills. Bucket capacity and refill period are immutable per pair.
Capacity is bounded to uint128 and refill interval to (0,30 days]. There is no administrative refill.
Amounts use raw token units, not a USD oracle.

`setMaxTransfer(next)` is owner-only and nonReentrant: the intended owner is the deployment timelock.
It requires outbound initiation paused and `0 < next <= rateCapacity`. It changes `maxTransfer`,
emits `TransferLimitChanged(previous,next,inboundMaximum)`, and leaves both buckets and lane pause
state unchanged. No chain-to-chain atomic execution is available: coordinate the two endpoints and
verify their approved settings before resuming outbound initiation.

`maxTransfer` limits NEW outgoing deposits (gross amount) and burns. `inboundMaxTransfer` starts
at the initial maximum and can only increase to the highest value passed to the setter. Incoming
completions use that historical ceiling, retaining the ability to complete claims initiated before
a decrease. They still need authenticated messages, available inbound rate capacity and all normal
backing/replay checks. Lowering the outgoing maximum is not an inbound emergency restriction; use
inbound pause for suspicious messages. Historical inbound acceptance has no automatic expiry.

The paired current maxima, historical inbound ceilings, capacities and refill periods must match
approved configuration. Operational preflight verifies all four. For a fresh deployment,
`inboundMaxTransferRaw` must equal `maxTransferRaw`; after a decrease, the former stays higher.


## Multiplier snapshots

A permissionless keeper calls `publishMetadata`, paying the Core message fee. The source reads
uiMultiplier/newUIMultiplier/effectiveAt directly from the original. If no future schedule exists,
it normalizes next=current and effectiveAt=0. No caller can submit arbitrary multiplier values.

Destination verifies the METADATA VAA before passing its emitter sequence to WrappedAsset.
Only later sequences replace current state. Older authenticated snapshots are consumed but ignored.
A replacement can supersede or cancel a pending schedule. Observed timestamp must not decrease,
must be no more than 5 minutes in the future and no older than configured metadataMaxAge.
Current and next must be positive; a future schedule must be after the observation time.

Raw ERC20 balances, supply, allowances and burn/redeem are independent from snapshots.
UI accessors and conversions revert before the first snapshot or when stale. `snapshot()` remains
readable for monitoring. This is an intentional fail-closed deviation from the happy-path behavior
of ERC-8056 UI consumers, which must handle reverts and check metadataFresh. ERC-8056 is a draft.
A source cancellation cannot be known before its message arrives; a schedule may temporarily be
wrong within the freshness bound. These values are **not a price oracle**. No double application
to an already multiplier-adjusted price is permitted in an integrating frontend.
