// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Fixture} from "./Fixture.sol";
import {SourceVault} from "../src/SourceVault.sol";
import {DestinationBridge} from "../src/DestinationBridge.sol";
import {WormholeEndpoint} from "../src/WormholeEndpoint.sol";
import {TokenBucket} from "../src/TokenBucket.sol";
import {BridgeMessage} from "../src/BridgeMessage.sol";
import {IWormholeCore} from "../src/interfaces/IWormholeCore.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {TimelockController} from "@openzeppelin/contracts/governance/TimelockController.sol";

contract TransferLimitGovernanceTest is Fixture {
    event TransferLimitChanged(uint256 previous, uint256 next, uint256 inboundMaximum);

    function setUp() public override {
        super.setUp();
        WormholeEndpoint.Config memory c = _config(address(sourceCore), DESTINATION);
        c.maxTransfer = 100 ether;
        vault = new SourceVault(c, address(asset), TREASURY);
        c = _config(address(destinationCore), SOURCE);
        c.maxTransfer = 100 ether;
        bridge = new DestinationBridge(c, address(asset), "Stock", "sSTK", 1 days);
        wrapped = bridge.wrappedAsset();
        vault.setPeer(address(bridge), address(wrapped));
        bridge.setPeer(address(vault), address(asset));
        vault.unpause(3);
        bridge.unpause(3);
        vm.prank(ALICE);
        asset.approve(address(vault), type(uint256).max);
    }

    function _changeBoth(uint256 next) private {
        vault.pause(1);
        bridge.pause(1);
        vault.setMaxTransfer(next);
        bridge.setMaxTransfer(next);
    }

    function test_UsersGuardianAndTreasuryCannotChangeMaximum() public {
        vault.pause(1);
        bridge.pause(1);
        address[3] memory callers = [ALICE, GUARDIAN, TREASURY];
        for (uint256 i; i < callers.length; ++i) {
            vm.prank(callers[i]);
            vm.expectRevert(abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, callers[i]));
            vault.setMaxTransfer(200 ether);
            vm.prank(callers[i]);
            vm.expectRevert(abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, callers[i]));
            bridge.setMaxTransfer(200 ether);
        }
    }

    function test_ZeroAndAboveCapacityRejected() public {
        vault.pause(1);
        uint256[3] memory invalid = [uint256(0), BUCKET_CAPACITY + 1, type(uint256).max];
        for (uint256 i; i < invalid.length; ++i) {
            vm.expectRevert(WormholeEndpoint.InvalidConfiguration.selector);
            vault.setMaxTransfer(invalid[i]);
        }
        assertEq(vault.maxTransfer(), 100 ether);
        assertEq(vault.inboundMaxTransfer(), 100 ether);
    }

    function test_ChangeRequiresOutboundPauseAndDoesNotResume() public {
        vm.expectRevert(WormholeEndpoint.OutboundMustBePaused.selector);
        vault.setMaxTransfer(200 ether);
        vault.pause(2);
        vm.expectRevert(WormholeEndpoint.OutboundMustBePaused.selector);
        vault.setMaxTransfer(200 ether);
        vault.pause(1);
        vm.expectEmit(false, false, false, true, address(vault));
        emit TransferLimitChanged(100 ether, 200 ether, 200 ether);
        vault.setMaxTransfer(200 ether);
        assertEq(vault.pausedLanes(), 3);
        assertEq(vault.maxTransfer(), 200 ether);
        assertEq(vault.inboundMaxTransfer(), 200 ether);
    }

    function test_LimitChangeRequiresMatureTimelockOperation() public {
        address[] memory members = new address[](1);
        members[0] = address(this);
        TimelockController timelock = new TimelockController(2 days, members, members, address(0));
        vault.transferOwnership(address(timelock));
        bytes memory accept = abi.encodeCall(vault.acceptOwnership, ());
        timelock.schedule(address(vault), 0, accept, bytes32(0), bytes32(0), 2 days);
        vm.warp(block.timestamp + 2 days);
        timelock.execute(address(vault), 0, accept, bytes32(0), bytes32(0));
        vm.prank(GUARDIAN);
        vault.pause(1);
        vm.expectRevert(abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, address(this)));
        vault.setMaxTransfer(200 ether);
        bytes memory change = abi.encodeCall(vault.setMaxTransfer, (200 ether));
        timelock.schedule(address(vault), 0, change, bytes32(0), bytes32(uint256(1)), 2 days);
        vm.expectRevert();
        timelock.execute(address(vault), 0, change, bytes32(0), bytes32(uint256(1)));
        assertEq(vault.maxTransfer(), 100 ether);
        vm.warp(block.timestamp + 2 days);
        timelock.execute(address(vault), 0, change, bytes32(0), bytes32(uint256(1)));
        assertEq(vault.maxTransfer(), 200 ether);
        assertEq(vault.pausedLanes(), 1);
    }

    function test_ChangeDoesNotRefillOrResetEitherBucket() public {
        for (uint256 i; i < 10; ++i) {
            _mint(100 ether);
        }
        vault.completeRedemption(_redeem(100 ether, ALICE));
        assertEq(vault.outboundAvailable(), 0);
        assertEq(bridge.inboundAvailable(), 5 ether);
        uint256 sourceIn = vault.inboundAvailable();
        uint256 destinationOut = bridge.outboundAvailable();
        _changeBoth(50 ether);
        _changeBoth(200 ether);
        _changeBoth(200 ether);
        assertEq(vault.outboundAvailable(), 0);
        assertEq(bridge.inboundAvailable(), 5 ether);
        assertEq(vault.inboundAvailable(), sourceIn);
        assertEq(bridge.outboundAvailable(), destinationOut);
        vm.warp(block.timestamp + 30 minutes);
        assertEq(vault.outboundAvailable(), 500 ether);
        assertEq(bridge.inboundAvailable(), 505 ether);
    }

    function test_LoweringPreservesPendingDepositsAndBurnsAndReplayProtection() public {
        bytes memory pendingDeposit = _deposit(100 ether, ALICE);
        _mint(100 ether);
        bytes memory pendingReturn = _redeem(50 ether, ALICE);
        _changeBoth(10 ether);
        assertEq(vault.inboundMaxTransfer(), 100 ether);
        assertEq(bridge.inboundMaxTransfer(), 100 ether);
        // Incoming completions remain available while new requests stay paused.
        bridge.completeDeposit(pendingDeposit);
        vault.completeRedemption(pendingReturn);
        assertEq(vault.locked(), 149 ether);
        assertEq(wrapped.totalSupply(), 149 ether);
        vm.expectRevert(WormholeEndpoint.MessageAlreadyConsumed.selector);
        bridge.completeDeposit(pendingDeposit);
        vm.expectRevert(WormholeEndpoint.MessageAlreadyConsumed.selector);
        vault.completeRedemption(pendingReturn);
        vault.unpause(1);
        bridge.unpause(1);
        vm.prank(ALICE);
        vm.expectRevert(WormholeEndpoint.TransferTooLarge.selector);
        vault.deposit(10 ether + 1, ALICE);
        vm.prank(ALICE);
        vm.expectRevert(WormholeEndpoint.TransferTooLarge.selector);
        bridge.redeem(10 ether + 1, ALICE);
        vault.completeRedemption(_redeem(10 ether, ALICE));
        assertEq(vault.locked(), 139 ether);
    }

    function test_RaisingEnablesLargerRoundTripWithinBucketCapacity() public {
        _changeBoth(500 ether);
        vault.unpause(1);
        bridge.unpause(1);
        _mint(500 ether);
        vault.completeRedemption(_redeem(497.5 ether, ALICE));
        assertEq(vault.locked(), 0);
        assertEq(wrapped.totalSupply(), 0);
        assertEq(vault.inboundMaxTransfer(), 500 ether);
        assertEq(bridge.inboundMaxTransfer(), 500 ether);
        assertEq(asset.balanceOf(TREASURY), 2.5 ether);
    }

    function test_LegacyCeilingStillRejectsLargerAuthenticatedMessage() public {
        _changeBoth(200 ether);
        _changeBoth(10 ether);
        vault.unpause(1);
        bytes memory encoded = _deposit(1 ether, ALICE);
        IWormholeCore.VM memory m = abi.decode(encoded, (IWormholeCore.VM));
        BridgeMessage.Transfer memory data = abi.decode(m.payload, (BridgeMessage.Transfer));
        data.amount = 200 ether + 1;
        m.payload = abi.encode(data);
        encoded = abi.encode(m);
        destinationCore.attest(encoded);
        vm.expectRevert(WormholeEndpoint.TransferTooLarge.selector);
        bridge.completeDeposit(encoded);
        assertEq(bridge.inboundMaxTransfer(), 200 ether);
        assertEq(bridge.inboundAvailable(), BUCKET_CAPACITY);
        assertEq(wrapped.totalSupply(), 0);
    }

    function test_PendingLegacyMessageRemainsRateLimitedAndRetryable() public {
        bytes[] memory firstBatch = new bytes[](10);
        for (uint256 i; i < 10; ++i) {
            firstBatch[i] = _deposit(100 ether, ALICE);
        }
        vm.warp(block.timestamp + 1 hours);
        bytes memory pending = _deposit(100 ether, ALICE);
        for (uint256 i; i < 10; ++i) {
            bridge.completeDeposit(firstBatch[i]);
        }
        _changeBoth(10 ether);
        vm.expectRevert(abi.encodeWithSelector(TokenBucket.RateLimitExceeded.selector, 5 ether, 99.5 ether));
        bridge.completeDeposit(pending);
        vm.warp(block.timestamp + 1 hours);
        bridge.completeDeposit(pending);
        assertEq(wrapped.totalSupply(), 1094.5 ether);
        assertEq(vault.locked(), wrapped.totalSupply());
    }

    function attemptMaximumChangeFromTokenCallback() external {
        require(msg.sender == address(asset), "test token only");
        vault.pause(1);
        vault.setMaxTransfer(200 ether);
    }

    function test_MaximumCannotChangeThroughOwnerCallbackDuringDeposit() public {
        asset.setCallback(address(this), abi.encodeCall(this.attemptMaximumChangeFromTokenCallback, ()));
        _mint(100 ether);
        assertFalse(asset.callbackSucceeded());
        assertEq(bytes4(asset.callbackResult()), bytes4(keccak256("ReentrancyGuardReentrantCall()")));
        assertEq(vault.maxTransfer(), 100 ether);
        assertEq(vault.inboundMaxTransfer(), 100 ether);
        assertEq(vault.pausedLanes(), 0);
    }

    function testFuzz_InboundCeilingNeverDecreasesAcrossChanges(uint256 first, uint256 second) public {
        first = bound(first, 1, BUCKET_CAPACITY);
        second = bound(second, 1, BUCKET_CAPACITY);
        _changeBoth(first);
        _changeBoth(second);
        uint256 expected = first > 100 ether ? first : 100 ether;
        if (second > expected) expected = second;
        assertEq(vault.maxTransfer(), second);
        assertEq(bridge.maxTransfer(), second);
        assertEq(vault.inboundMaxTransfer(), expected);
        assertEq(bridge.inboundMaxTransfer(), expected);
    }
}
