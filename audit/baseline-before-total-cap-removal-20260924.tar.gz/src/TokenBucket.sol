// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";

/// @notice Raw-unit rolling token bucket. No discrete reset at clock boundaries.
library TokenBucket {
    struct State {
        uint256 available;
        uint256 updatedAt;
    }
    error RateLimitExceeded(uint256 available, uint256 requested);

    function remaining(State storage self, uint256 capacity, uint256 period) internal view returns (uint256) {
        uint256 elapsed = block.timestamp - self.updatedAt;
        if (elapsed >= period) return capacity;
        return Math.min(capacity, self.available + Math.mulDiv(elapsed, capacity, period));
    }

    function consume(State storage self, uint256 capacity, uint256 period, uint256 amount) internal {
        uint256 available = remaining(self, capacity, period);
        if (amount > available) revert RateLimitExceeded(available, amount);
        self.available = available - amount;
        self.updatedAt = block.timestamp;
    }
}
