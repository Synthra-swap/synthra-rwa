# Validation evidence — 24 September 2026

Local toolchain: Foundry 1.5.1-stable (b0a9dd9ceda36f63e2326ce530c10e6916f4b8a2),
Solidity 0.8.28 (7893614a), Slither 0.11.3, Python 3.14.6. EVM Paris, optimizer 200,
no CBOR/bytecode metadata. CI declares Foundry 1.5.1 and Python 3.11 but has not been run remotely.

`bash tools/check.sh` completed successfully for this source candidate. The reports below are
packaged and hashed with the source snapshot; the independent audit remains outstanding.
The later twelve-stock expansion changed integration tests and their fixture, not production source
or local unit tests. The 92/49/17 baseline was retained, with mutation input hashes rechecked;
the 19 integration tests and formatting check were newly run for that expansion.

| Check | Result | Evidence |
| --- | --- | --- |
| Solidity suite | 92 passed, 0 failed, 0 skipped | `audit/unit-tests.log` |
| Audit profile | 92 passed; 6 fuzz tests × 2,048 cases | `audit/audit-tests.log` |
| Stateful conservation | 512 runs × depth 128 = 65,536 handler calls; 0 unexpected reverts | `audit/audit-tests.log` |
| Pending-message drain | afterInvariant delivers outstanding messages and checks locked = supply | `test/BridgeInvariant.t.sol` |
| Native binary signed VAAs | 15 tests, including recovery with different Guardian keys in both directions | `test/SignedVAA.t.sol` |
| Fee behavior | 100 → 99.5 wrapped + immediate 0.5 treasury; failed fee/publication fully reverts | `test/Bridge.t.sol` |
| Treasury rotation / immediate pause | 7 tests: authority, timing, invalid recipients, backing, callback protection, rollback and emergency action | `test/TreasuryGovernance.t.sol` |
| Asset expansion | 2 local tests: add a thirteenth pair; isolate messages and pauses | `test/AssetExpansion.t.sol` |
| Deployment simulation | Both sides created paused and owned by newly created timelock; placeholders rejected | `test/DeploymentConfig.t.sol` |
| Operational-tool validation | 49 Python tests passed, including expected treasury rotation checks | `audit/python-tests.log`, `tools/test_*.py` |
| Real-network fork simulations | 19 passed on 24 September; all 12 selected stocks, treasury rotation and issuer interference | `audit/live-fork-tests.log`, `docs/TWELVE_ASSET_VALIDATION.md` |
| Mutation sensitivity | All 17 compiling mutations detected, including treasury authority and reentrancy | `audit/mutation-report.json` |
| Upstream provenance | Historical: 63 files byte-matched on 23 September; dependencies unchanged and local lock rechecked | `audit/dependency-verification.json` |
| Slither | 0 High/Medium, 6 reviewed Low timestamp findings | `audit/slither.json`, `docs/SECURITY_ANALYSIS.md` |
| Formatting / dependencies | Passed; 65 dependency files match lock | `tools/check.sh`, `vendor/SHA256SUMS.json` |
| Demo | Successful simulation; 9.95 minted, 4 redeemed, 5.95 remaining, 0.05 immediately paid | `audit/demo.log` |

## Coverage

These are instrumented Foundry coverage numbers, not a proof of correctness or absence of vulnerabilities.
Source-only total: 253/255 lines (99.22%), 49/49 functions (100%), 41/47 branches (87.23%).

| Contract | Lines | Functions | Branches |
| --- | --- | --- | --- |
| SourceVault | 56/57 | 7/7 | 10/12 |
| DestinationBridge | 25/26 | 5/5 | 2/5 |
| WormholeEndpoint | 99/99 | 18/18 | 20/21 |
| WrappedAsset | 64/64 | 17/17 | 7/7 |
| TokenBucket | 9/9 | 2/2 | 2/2 |

Deployment script: 51/51 lines and 3/3 functions; 10/16 branches. Full file-by-file summary and
LCOV in `audit/coverage.log` and `audit/coverage.lcov`. Uncovered branches include invalid deployment/
configuration paths and redundant remote-token rejection; these remain visible for auditor review.

Production runtime sizes: SourceVault 11,791 bytes, DestinationBridge 9,787 bytes, WrappedAsset
4,455 bytes; all below EIP-170's 24,576-byte limit. Gas output is in `audit/gas-report.log` and
includes artificial mock overhead; it is not a gas-cost estimate for the live chains.

## What has not been established

- Nineteen fork tests passed on 24 September against the current treasury-rotation source.
  See `TWELVE_ASSET_VALIDATION.md` and `audit/live-fork-tests.log`.
  Real token balances were injected locally, and return-flow attestations were mocked. No public
  transaction was broadcast, and no Synthra live end-to-end transfer has been demonstrated.
- An actual Robinhood-origin Guardian-set-7 VAA was verified on both real Core implementations;
  it belongs to another emitter and uses consistency 202. Our intended level-0 policy and Arc-origin
  Guardian observation remain unproven by this evidence.
- All twelve selected stocks passed compatibility and issuer-interference scenarios. Their token
  proxies resolve to the same implementation at the pinned recent block. Deployed escrow/treasury
  eligibility, issuer role governance, production risk values and operator addresses remain unresolved.
- Production pair preflight/relay execution still needs deployed endpoints and approved real configs.
  Robinhood's public RPC returned no historical state for the finalized block; latest reads are
  separately labeled and do not satisfy that gate.
- Independent review, issuer/distribution review, hosted relayer, durable indexer/reconciliation,
  frontend and liquidity integration remain outstanding.

Foundry emits non-blocking debug-source-parser warnings during the demo for certain test/vendor
files. Compilation, script assertions, emitted logs and final exit code confirm successful execution.
One intentional Slither suppression ignores only the unused human-readable Core diagnostic string;
validity is checked explicitly. Disposition is documented, not represented as a detector-free audit.
